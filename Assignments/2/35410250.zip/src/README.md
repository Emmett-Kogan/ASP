# Assignment 2
## Contributor(s)
1. Emmett Kogan

## Build instructions
1. Run `make`, the `default` rule of the makefile builds the `combiner` executable, and the `clean` rule removes the executable.
2. I also made a test script htat runs using the given testfiles. To run the given tests you can just run `./test.sh` which will run 
all of the given testcases from assignment.
